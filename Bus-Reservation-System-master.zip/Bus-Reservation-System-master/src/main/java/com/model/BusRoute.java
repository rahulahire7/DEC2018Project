package com.model;

public class BusRoute {

}
