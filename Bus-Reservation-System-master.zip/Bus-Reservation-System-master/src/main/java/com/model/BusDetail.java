package com.model;

public class BusDetail {

	private String busType;
	private String operatorName;
	private String busNo;
	private int noOfSeats;
	

	
}
