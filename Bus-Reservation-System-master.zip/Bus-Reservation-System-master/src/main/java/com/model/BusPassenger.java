package com.model;

public class BusPassenger {

}
