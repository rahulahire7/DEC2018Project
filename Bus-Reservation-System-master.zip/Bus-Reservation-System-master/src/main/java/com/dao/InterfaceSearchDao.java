package com.dao;

import com.model.BusSearch;

public interface InterfaceSearchDao {

	Object searchBus(BusSearch b);

	
}
