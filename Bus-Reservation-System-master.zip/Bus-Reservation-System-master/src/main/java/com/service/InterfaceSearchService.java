package com.service;

import com.model.BusSearch;

public interface InterfaceSearchService {

	Object searchBus(BusSearch b);

}
